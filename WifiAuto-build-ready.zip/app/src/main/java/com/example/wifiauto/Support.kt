package com.example.wifiauto

import android.content.Context
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/** سجل بسيط يظهر في شاشة التطبيق. */
object AppLog {
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val buf = StringBuilder()

    @Volatile
    var listener: ((String) -> Unit)? = null

    @Synchronized
    fun add(msg: String) {
        buf.append(fmt.format(Date())).append("  ").append(msg).append('\n')
        if (buf.length > 20000) buf.delete(0, buf.length - 15000)
        listener?.invoke(buf.toString())
    }

    @Synchronized
    fun text(): String = buf.toString()
}

class Settings(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("wifi_auto", Context.MODE_PRIVATE)

    var ssid: String
        get() = p.getString("ssid", "") ?: ""
        set(v) = p.edit().putString("ssid", v).apply()

    var interval: Int
        get() = p.getInt("interval", 20)
        set(v) = p.edit().putInt("interval", v).apply()

    var rootMode: Boolean
        get() = p.getBoolean("root", false)
        set(v) = p.edit().putBoolean("root", v).apply()

    var running: Boolean
        get() = p.getBoolean("running", false)
        set(v) = p.edit().putBoolean("running", v).apply()
}

object RootShell {
    fun run(cmd: String, timeoutSec: Long = 20): String? = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) {
            p.destroy()
            null
        } else {
            p.inputStream.bufferedReader().readText()
        }
    } catch (e: Exception) {
        null
    }

    fun available(): Boolean = run("id")?.contains("uid=0") == true
}

object RootWifi {
    /** يحذف الشبكة المحفوظة ثم يضيفها ويتصل بها من جديد (أندرويد 11+ وروت). */
    fun forgetAndReconnect(ssid: String) {
        val list = RootShell.run("cmd wifi list-networks").orEmpty()
        var forgot = 0
        for (line in list.lines()) {
            val id = line.trim().split(Regex("\\s+")).firstOrNull().orEmpty()
            if (id.isNotEmpty() && id.all { it.isDigit() } && line.contains(ssid)) {
                RootShell.run("cmd wifi forget-network $id")
                forgot++
            }
        }
        AppLog.add("تم حذف $forgot شبكة محفوظة")
        val quoted = "'" + ssid.replace("'", "'\\''") + "'"
        val out = RootShell.run("cmd wifi connect-network $quoted open").orEmpty().trim()
        AppLog.add("إعادة الاتصال: " + out.ifEmpty { "تم الأمر" })
    }
}

class MemoryCookieJar : CookieJar {
    private val store = mutableListOf<Cookie>()

    @Synchronized
    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        for (c in cookies) {
            store.removeAll { it.name == c.name && it.domain == c.domain && it.path == c.path }
            store.add(c)
        }
    }

    @Synchronized
    override fun loadForRequest(url: HttpUrl): List<Cookie> = store.filter { it.matches(url) }
}
