package com.example.wifiauto

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import okhttp3.CookieJar
import okhttp3.FormBody
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.io.File
import java.net.URL
import java.util.concurrent.TimeUnit

enum class Status { NO_WIFI, NO_INTERNET, OK }

class Engine(context: Context) {
    private val app = context.applicationContext
    private val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    companion object {
        const val CHECK_URL = "http://connectivitycheck.gstatic.com/generate_204"
        const val UA = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
        private val WORDS = listOf(
            "اتصال", "مجاني", "connect", "free", "login",
            "continue", "accept", "agree", "start", "internet"
        )
        private val JS_REDIRECT = Regex("""location(?:\.href)?\s*=\s*["']([^"']+)["']""")
        private val META_URL = Regex("""url\s*=\s*(.+)""", RegexOption.IGNORE_CASE)
    }

    // ---------- الشبكة ----------

    @Suppress("DEPRECATION")
    private fun wifiNetwork(): Network? = cm.allNetworks.firstOrNull {
        cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    }

    /** يربط طلبات التطبيق بالواي فاي حتى لو كانت بيانات الجوال مفعّلة. */
    fun bindToWifi(): Boolean {
        val n = wifiNetwork()
        cm.bindProcessToNetwork(n)
        return n != null
    }

    fun waitForWifi(timeoutSec: Int): Boolean {
        repeat(timeoutSec) {
            if (bindToWifi()) return true
            Thread.sleep(1000)
        }
        return false
    }

    private fun client(follow: Boolean, jar: CookieJar = CookieJar.NO_COOKIES): OkHttpClient =
        OkHttpClient.Builder()
            .followRedirects(follow)
            .followSslRedirects(follow)
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .cookieJar(jar)
            .addInterceptor { chain ->
                chain.proceed(chain.request().newBuilder().header("User-Agent", UA).build())
            }
            .build()

    fun isOnline(): Boolean = try {
        client(false).newCall(Request.Builder().url(CHECK_URL).build()).execute()
            .use { it.code == 204 }
    } catch (e: Exception) {
        false
    }

    fun status(): Status {
        if (!bindToWifi()) return Status.NO_WIFI
        return if (isOnline()) Status.OK else Status.NO_INTERNET
    }

    // ---------- استعادة الاتصال ----------

    fun recover(rootMode: Boolean, ssid: String, st: Status) {
        if (rootMode) {
            AppLog.add("حذف الشبكة وإعادة إضافتها...")
            RootWifi.forgetAndReconnect(ssid)
            Thread.sleep(5000)
            if (!waitForWifi(30)) {
                AppLog.add("لم يتصل الجهاز بالشبكة بعد")
                return
            }
            Thread.sleep(3000)
        } else if (st == Status.NO_WIFI) {
            AppLog.add("غير متصل بالواي فاي. إعادة الاتصال تلقائياً تتطلب وضع الروت")
            return
        }
        AppLog.add(if (login()) "تم تسجيل الدخول ✔" else "فشل تسجيل الدخول ✘")
    }

    // ---------- تسجيل الدخول من صفحة الشبكة ----------

    fun login(): Boolean {
        if (!bindToWifi()) {
            AppLog.add("لا توجد شبكة واي فاي متصلة")
            return false
        }
        val http = client(true, MemoryCookieJar())
        var page = try {
            fetch(http, Request.Builder().url(CHECK_URL).build())
        } catch (e: Exception) {
            AppLog.add("تعذر فتح صفحة الشبكة: ${e.message}")
            return false
        }

        for (step in 1..5) {
            if (isOnline()) return true
            val (url, html) = page
            val doc = Jsoup.parse(html, url)

            val form = doc.select("form").maxByOrNull { score(formText(it)) }
            val link = doc.select("a[href]")
                .filter { it.absUrl("href").startsWith("http") }
                .maxByOrNull { score(it.text() + " " + it.attr("title")) }
            val fs = form?.let { score(formText(it)) } ?: -1
            val ls = link?.let { score(it.text() + " " + it.attr("title")) } ?: -1
            val redirect = metaRefresh(doc) ?: JS_REDIRECT.find(html)?.groupValues?.get(1)

            page = try {
                when {
                    form != null && fs > 0 && fs >= ls -> submit(http, form, url)
                    link != null && ls > 0 -> fetch(
                        http,
                        Request.Builder().url(link.absUrl("href")).header("Referer", url).build()
                    )
                    redirect != null -> fetch(
                        http,
                        Request.Builder().url(URL(URL(url), redirect).toString()).build()
                    )
                    form != null -> submit(http, form, url)
                    else -> {
                        saveDebug(url, html)
                        return false
                    }
                }
            } catch (e: Exception) {
                AppLog.add("خطأ أثناء تسجيل الدخول: ${e.message}")
                return false
            }
            Thread.sleep(1500)
        }
        return isOnline()
    }

    private fun fetch(http: OkHttpClient, req: Request): Pair<String, String> =
        http.newCall(req).execute().use { Pair(it.request.url.toString(), it.body?.string() ?: "") }

    private fun submit(http: OkHttpClient, form: Element, pageUrl: String): Pair<String, String> {
        val action = form.absUrl("action").ifEmpty { pageUrl }
        val fields = formFields(form)
        AppLog.add("ضغط زر الاتصال: $action")
        val req = if (form.attr("method").equals("post", ignoreCase = true)) {
            val body = FormBody.Builder().apply { fields.forEach { (k, v) -> add(k, v) } }.build()
            Request.Builder().url(action).header("Referer", pageUrl).post(body).build()
        } else {
            val u = action.toHttpUrl().newBuilder()
                .apply { fields.forEach { (k, v) -> addQueryParameter(k, v) } }
                .build()
            Request.Builder().url(u).header("Referer", pageUrl).build()
        }
        return fetch(http, req)
    }

    private fun formFields(form: Element): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        for (e in form.select("input[name], select[name], textarea[name], button[name]")) {
            if (e.hasAttr("disabled")) continue
            val name = e.attr("name")
            when (e.tagName()) {
                "select" -> {
                    val opt = e.selectFirst("option[selected]") ?: e.selectFirst("option")
                    val v = opt?.let { if (it.hasAttr("value")) it.attr("value") else it.text() } ?: ""
                    out.add(Pair(name, v))
                }
                "textarea" -> out.add(Pair(name, e.text()))
                "button" -> out.add(Pair(name, e.attr("value")))
                else -> {
                    val type = e.attr("type").lowercase()
                    if ((type == "checkbox" || type == "radio") && !e.hasAttr("checked")) continue
                    if (type == "file" || type == "reset") continue
                    out.add(Pair(name, e.attr("value")))
                }
            }
        }
        return out
    }

    private fun formText(f: Element): String =
        f.text() + " " + f.select("input[type=submit], input[type=button], button")
            .joinToString(" ") { it.attr("value") + " " + it.text() }

    private fun score(text: String): Int {
        val t = text.lowercase()
        return WORDS.count { t.contains(it) }
    }

    private fun metaRefresh(doc: Document): String? {
        val content = doc.select("meta")
            .firstOrNull { it.attr("http-equiv").equals("refresh", ignoreCase = true) }
            ?.attr("content") ?: return null
        return META_URL.find(content)?.groupValues?.get(1)?.trim(' ', '\'', '"')?.ifEmpty { null }
    }

    private fun saveDebug(url: String, html: String) {
        try {
            val f = File(app.getExternalFilesDir(null), "portal_debug.html")
            f.writeText("<!-- $url -->\n$html")
            AppLog.add("لم أجد زر اتصال. حفظت الصفحة في: ${f.absolutePath}")
        } catch (e: Exception) {
            AppLog.add("لم أجد زر اتصال في الصفحة")
        }
    }
}
