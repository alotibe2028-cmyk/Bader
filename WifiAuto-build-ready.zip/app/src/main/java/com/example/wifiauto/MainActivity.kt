package com.example.wifiauto

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var s: Settings
    private lateinit var ssid: EditText
    private lateinit var interval: EditText
    private lateinit var rootSwitch: Switch
    private lateinit var toggle: Button
    private lateinit var test: Button
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        s = Settings(this)

        ssid = findViewById(R.id.ssid)
        interval = findViewById(R.id.interval)
        rootSwitch = findViewById(R.id.rootSwitch)
        toggle = findViewById(R.id.toggle)
        test = findViewById(R.id.test)
        logView = findViewById(R.id.log)
        scroll = findViewById(R.id.scroll)

        ssid.setText(s.ssid)
        interval.setText(s.interval.toString())
        rootSwitch.isChecked = s.rootMode

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        rootSwitch.setOnCheckedChangeListener { _, on ->
            if (on) {
                Thread {
                    val ok = RootShell.available()
                    runOnUiThread {
                        if (ok) {
                            AppLog.add("تم التحقق من صلاحية الروت ✔")
                        } else {
                            rootSwitch.isChecked = false
                            Toast.makeText(this, "لم تُمنح صلاحية الروت", Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
        }

        toggle.setOnClickListener {
            if (s.running) {
                stopService(Intent(this, WifiService::class.java))
            } else {
                if (ssid.text.toString().isBlank()) {
                    Toast.makeText(this, "اكتب اسم الشبكة أولاً", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                save()
                s.running = true
                startForegroundService(Intent(this, WifiService::class.java))
            }
            refresh()
        }

        test.setOnClickListener {
            save()
            Thread {
                val engine = Engine(this)
                engine.recover(s.rootMode, s.ssid, engine.status())
            }.start()
        }
    }

    private fun save() {
        s.ssid = ssid.text.toString().trim()
        s.interval = interval.text.toString().toIntOrNull() ?: 20
        s.rootMode = rootSwitch.isChecked
    }

    private fun refresh() {
        toggle.text = if (s.running) "إيقاف" else "تشغيل"
    }

    override fun onResume() {
        super.onResume()
        refresh()
        logView.text = AppLog.text()
        AppLog.listener = { t ->
            runOnUiThread {
                logView.text = t
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            }
        }
    }

    override fun onPause() {
        AppLog.listener = null
        super.onPause()
    }
}
