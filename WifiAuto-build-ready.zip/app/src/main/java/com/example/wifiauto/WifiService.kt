package com.example.wifiauto

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

class WifiService : Service() {
    @Volatile
    private var running = false
    private var worker: Thread? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        if (worker == null) {
            running = true
            wakeLock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wifiauto:loop")
                .apply { acquire() }
            worker = Thread { loop() }.also { it.start() }
        }
        return START_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("wifi_auto", "واي فاي تلقائي", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "wifi_auto")
            .setContentTitle("واي فاي تلقائي يعمل")
            .setContentText("مراقبة الاتصال وإعادة الدخول تلقائياً")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1, n)
        }
    }

    private fun loop() {
        val s = Settings(this)
        val engine = Engine(this)
        AppLog.add("بدأ التشغيل — وضع الروت: ${if (s.rootMode) "مفعّل" else "معطّل"}")
        var fails = 0
        while (running) {
            try {
                val st = engine.status()
                if (st == Status.OK) {
                    fails = 0
                } else {
                    fails++
                    AppLog.add(
                        if (st == Status.NO_WIFI) "غير متصل بالواي فاي ($fails)"
                        else "لا يوجد إنترنت ($fails)"
                    )
                    if (fails >= 2) {
                        engine.recover(s.rootMode, s.ssid, st)
                        fails = 0
                    }
                }
            } catch (e: Exception) {
                AppLog.add("خطأ: ${e.message}")
            }
            try {
                Thread.sleep(maxOf(5, s.interval) * 1000L)
            } catch (e: InterruptedException) {
                break
            }
        }
    }

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        worker = null
        wakeLock?.let { if (it.isHeld) it.release() }
        getSystemService(ConnectivityManager::class.java).bindProcessToNetwork(null)
        Settings(this).running = false
        AppLog.add("تم الإيقاف")
        super.onDestroy()
    }
}
